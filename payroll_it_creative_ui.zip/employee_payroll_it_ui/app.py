from flask import Flask, render_template, redirect, url_for, request, session, send_file
from flask_sqlalchemy import SQLAlchemy
import io
from reportlab.pdfgen import canvas

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///payroll.db'
db = SQLAlchemy(app)

class Employee(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))
    department = db.Column(db.String(100))
    role = db.Column(db.String(20))  # 'admin' or 'employee'

class Salary(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    emp_id = db.Column(db.Integer, db.ForeignKey('employee.id'))
    basic = db.Column(db.Float)
    hra = db.Column(db.Float)
    da = db.Column(db.Float)
    other = db.Column(db.Float)
    deductions = db.Column(db.Float)

    @property
    def net(self):
        return self.basic + self.hra + self.da + self.other - self.deductions

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = Employee.query.filter_by(email=email, password=password).first()
        if user:
            session['user_id'] = user.id
            session['role'] = user.role
            return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user = Employee.query.get(session['user_id'])
    if session['role'] == 'admin':
        employees = Employee.query.all()
        return render_template('dashboard_admin.html', employees=employees)
    else:
        salary = Salary.query.filter_by(emp_id=user.id).first()
        return render_template('dashboard.html', employee=user, salary=salary)

@app.route('/download_payslip/<int:emp_id>')
def download_payslip(emp_id):
    employee = Employee.query.get(emp_id)
    salary = Salary.query.filter_by(emp_id=emp_id).first()
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer)
    p.drawString(100, 800, f"Payslip for: {employee.name}")
    p.drawString(100, 780, f"Basic: ₹{salary.basic}")
    p.drawString(100, 760, f"HRA: ₹{salary.hra}")
    p.drawString(100, 740, f"DA: ₹{salary.da}")
    p.drawString(100, 720, f"Other: ₹{salary.other}")
    p.drawString(100, 700, f"Deductions: ₹{salary.deductions}")
    p.drawString(100, 680, f"Net Pay: ₹{salary.net}")
    p.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"{employee.name}_payslip.pdf")

if __name__ == '__main__':
    app.run(debug=True)
